# Mean_Median_Skew

Explanation of Mean, Median, Mode, Skew and when to use what. 

## Data
- Data folder contains,

        Mean_Median.xlsx - Sample data to explain Mean, Median
        titanic.csv - Titanic dataset to show all skweness.
